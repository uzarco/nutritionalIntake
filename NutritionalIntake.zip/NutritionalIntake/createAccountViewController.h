//
//  createAccountViewController.h
//  NutritionalIntake
//
//  Created by aarias3 on 11/8/12.
//  Copyright (c) 2012 uzarco. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "intakeViewController.h"


@interface createAccountViewController : UIViewController

@end
