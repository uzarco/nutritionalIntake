//
//  intakeViewController.h
//  NutritionalIntake
//
//  Created by uzarco on 11/7/12.
//  Copyright (c) 2012 uzarco. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "createAccountViewController.h"

@interface intakeViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIButton *createAccount;

@end
